package com.example.paille_plus

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
